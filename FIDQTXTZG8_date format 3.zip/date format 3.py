""" Program to break down number of seconds into days, hours, minutes, and seconds.
"""

# Get user input
seconds = int(input('Enter seconds: '))

# 1 day = 86400 seconds
days = seconds // 86400

if days > 0:
    print(days, "Days", end=" ")

# 1 hour = 3600 seconds
hours = (seconds - (days * 86400)) // 3600

if hours > 0:
    print(hours, "Hours", end=" ")

# 1 minute = 60 seconds
minutes = (seconds - (days * 86400) - (hours * 3600)) // 60

if minutes > 0:
    print(minutes, "Minutes", end=" ")

remainingSeconds = seconds - (days * 86400) - (hours * 3600) - (minutes * 60)

if remainingSeconds > 0:
    print(remainingSeconds, "Seconds")