# Right Angle Triangle
n = int(input())
for i in range(n):
    print(' ' * (n - i) + ' /' , end= '')
    if i < n -1:
        print( ' ' * i , end = '')
    else:
        print('_' * i, end = '')
    print('|')